const cloudinary =require('cloudinary').v2;
const fs = require('fs');

cloudinary.config({
    cloud_name :process.env.CLOUDINARY_NAME,
    api_key : process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
})


const uploadCloudinary = (req,res, next)=>{
    const pathFile= req.file.path;
    const  uniqueName = new Date().toISOString();

    cloudinary.uploader.upload(
        pathFile,{
            resoucrce_typec: 'raw',
            public_id:`express-cloudinary-$(uniqueName)`,
            tags :`express-cloudinary`,
        },
        (err, Image)=>{
            if(err) return res.status(500).send(err)
            console.log("file to uploude cloudinary")


            fs.unlinkSync(pathFile)
            req.Image = image ;
            next();
        }
    )
}
module.exports = uploadCloudinary;